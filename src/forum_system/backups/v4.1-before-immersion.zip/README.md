<div align="center">

# Awesome Chinese Folk Game
### 未明旧案柜 · 入夜，再查

**离线论坛推理游戏 × 可扩展民俗悬疑资料库**  
**9 个可玩案卷 · 58 个储备主题 · 12 幅预渲染现场**

[开始游玩](#开始游玩) · [完整案卷目录](docs/case_list.md) · [玩法手册](docs/game_manual.md) · [English](#english)

![未明旧案柜封面](assets/cover_banner.png)

</div>

> 放下去六盏，飘回来七盏。  
> 有人在一张被裁掉的报纸里，等了六年。

这不是一张游戏宣传页。你会真正进入帖子、留下追问、私信相关人，走进线索指向的现场，再把互相矛盾的材料拼回同一个夜晚。我们不替传闻作证，先替没能留下名字的人保管证据。

仓库由原 `wanxiang-forum` 整理而来，保留 V3 的独立旧案与 V4《寄名簿》连续主线。人物、案件和画面不使用《頭七》的角色、剧情或资产；不采用通用营销网页模板。

## 开始游玩

```sh
# 进入下载或解压后的项目根目录
cd awesome-chinese-folk-game
python3 demo/run_demo.py
```

Python 3.9+，**无需 pip 安装、账号、后端数据库或 API Key**。自动打开 **http://127.0.0.1:4173/**。正式入口也可用 `python3 main.py`。

没有 Python？直接打开 **`src/forum_system/index.html`**，保留完整 `src/` 目录即可离线玩。更多方式见 [安装指南](docs/install_guide.md)。

- 第一次玩：从《借灯人》的求助帖开始。
- 想进入连续故事：顶栏 **案卷 → 寄名簿 → 灯灭之前**。
- 想接着旧存档：使用原来的主机名与端口；改路径或浏览器前，在设置中**导出整柜**。

## 真正的调查循环

**读帖 → 标记证据 → 私信核验 → 实地取证 → 配对并解释 → 回访复勘 → 报告归档**

- 续帖和第二处现场由证据、推断解锁，不是一屏全部摊开的素材。
- 连续案的配对不只“选中即通过”：必须说明两份材料支持什么；误判有反馈，可修正。
- 时间、镜位、邮路与授权各用不同核验，不把每案都做成同一把密码锁。
- 公开或暂缓公开影响下一夜的交接说明，两条路径都可继续，不靠造假解锁“好结局”。

![实际游玩步骤节选](assets/preview_gif.gif)

<sub>GIF 为真实操作过程的关键帧节选，省略阅读与等待时间，不是完整实时录像。</sub>

## 九个可玩案卷

| 案卷 | 主题与调查方向 | 关系 |
|---|---|---|
| 001 · 借灯人 | 河灯、旧闻、被漏记的人 | 独立旧案 |
| 002 · 空轿照夜 | 阴亲与古宅 | 独立旧案 |
| 003 · 铃过无名关 | 归乡路引与身份 | 独立旧案 |
| 004 · 年夜缺席 | 守岁与空席 | 独立旧案 |
| 005 · 最后一折 | 水乡阴戏与旧事 | 独立旧案 |
| 006 · 灯灭之前 | 命灯、隔墙听声、被改写的死期 | 寄名簿 · 第一夜 |
| 007 · 镜中无籍 | 旧镜、寄名衣物、身份记录 | 寄名簿 · 第二夜 |
| 008 · 井底回邮 | 封井、镇石、一封信的真实邮路 | 寄名簿 · 第三夜 |
| 009 · 归宗空席 | 归宗、层叠封存、更正与授权 | 寄名簿 · 第四夜 |

《寄名簿》每夜 **8 篇帖子 / 12 份线索 / 6 条解释 / 2 处现场 / 1 个核验谜题 / 2 种归档方向**。后续案随前案归档开放。每夜 35–50 分钟是创作时估算，未做真人游玩时长标定。

<details>
<summary>查看真实界面截图（结局图另置，默认不展示剧透）</summary>

### 夜班论坛
![论坛首页](assets/screenshots/forum-home.png)
### 实地调查
![现场调查](assets/screenshots/investigation.png)
### 证据手记
![线索手记](assets/screenshots/evidence-board.png)

[反转结局截图（剧透）](assets/screenshots/ending-spoiler.png)

</details>

## 58 个主题，不冒充 58 个成品

用户提供的两批方向去重后为 **28 + 30 = 58**。每个方向一篇 Markdown，无数字前缀，便于长期扩容。

每篇包括：民俗设定、现场疑点、关键线索、拼图逻辑、折叠反转、玩法衔接建议和开发风险。保留参考意图，但指出“定时毒效”“读取记忆”“后代继承罪责”等逻辑或表达问题，避免机械堆砌。

- [传统民俗参考](cases/classic-folk-cases/)：阴亲、赶尸、风水、阴戏、狐仙、童谣等 28 项。
- [新收集参考](cases/exclusive-folk-cases/)：命灯、寄名、古镜、封井、夜巡、归宗等 30 项。
- [完整目录](docs/case_list.md) / [机器可读目录](cases/catalog.json)。

**`planned` 只代表写作储备，不出现在可玩案卷柜。** `exclusive` 是分类名，不是独家版权声明。参考标题、民俗与医疗机制未经独立核实，资料是结构化摘要而非聊天逐字备份。

## 项目结构

```text
awesome-chinese-folk-game/
├── demo/                       # 一键体验入口与说明
├── src/
│   ├── forum_system/           # 原论坛前端、运行 assets、美术源稿、测试
│   ├── case_engine/            # 证据门槛、解释判定、存档标准化
│   ├── folk_parser/            # 读取 cases，校验并编译离线快照
│   └── utils/                  # 路径、配置与本地服务器
├── cases/
│   ├── classic-folk-cases/     # 28 篇待开发主题 Markdown
│   ├── exclusive-folk-cases/   # 30 篇待开发主题 Markdown
│   ├── playable/              # 9 案元数据与可执行 JSON 剧情
│   ├── authoring/serial/      # 连续四案创作源
│   └── catalog.json           # 自动生成的全库目录
├── assets/                    # 仅用于仓库展示：封面 / 截图 / GIF
├── docs/                      # 安装、玩法、目录与迁移说明
├── tools/                     # 发布打包与展示素材生成
├── tests/                     # 库解析和共享引擎单元测试
├── releases/                  # 本地发布包与历史版本，不提交二进制
├── requirements.txt           # 运行只依赖 Python 标准库
└── main.py                    # 正式入口
```

**两个 assets 各司其职**：游戏读 `src/forum_system/assets/`；README 读根 `assets/`，相互不依赖。十二幅 1536×960 现场沿用项目已有的 Blender 本地预渲染，附 [美术源稿](src/forum_system/art/README.md)。

旧 `chapters/` 不再维护剧情，`data.js` 是自动生成且随项目提供的离线快照。详见 [迁移说明](docs/repository_migration.md)。

## 扩写与测试

```sh
python3 -m src.folk_parser check       # 检查格式、引用与推理图
python3 -m src.folk_parser build       # 更新离线数据与目录
python3 -m unittest discover -s tests # 库单元测试
node tests/engine.cjs                 # 引擎单元测试
python3 tools/package_release.py      # 打包统一目录
```

新增可玩本必须有独立的人物、时间线、伏笔、失败反馈和完整通关验证，不只是把一个参考条目改成 `playable`。详细流程见 [剧本库说明](cases/README.md)。浏览器测试命令见 [安装指南](docs/install_guide.md)，本次结果见 [迁移验收](docs/validation.md)。

## 内容、存档与授权

- 建议 16+。游戏含死亡、失踪和心理压迫，无血腥图片和贴脸惊吓；储备主题更沉重，请留意各篇内容。
- 音效默认关闭，关键音频均有文字。支持键盘、移动端热点按钮与关闭动态效果。
- 全部进度留在当前浏览器，没有追踪。换来源或清除浏览器数据前请导出存档。
- **尚未选择统一开源许可证**。参考资料不等于第三方改编授权；正式公开发行前需确认各类内容权利。[授权与来源说明](NOTICE.md)

---

## English

### A playable archive, not a landing page

**Awesome Chinese Folk Game / 未明旧案柜** is an offline, Chinese-language folk-horror investigation game. Read forum threads, interview fictional users through private messages, examine scenes, connect evidence and explain your deductions before filing a report.

The repository contains **9 playable cases**: five standalone mysteries plus the four-part **Register of Borrowed Names** cycle. The separate **58-theme Markdown library** is a writing reference collection, **not 58 additional playable games**. All gameplay text is currently in Chinese; this README is bilingual, not the game itself.

### Quick start

```sh
python3 demo/run_demo.py
# or
python3 main.py --no-browser
```

Python 3.9+, standard library only. The launcher validates the case library and opens `http://127.0.0.1:4173/`. For a server-free offline session, open `src/forum_system/index.html` while keeping the full `src/` directory intact.

### Authoring architecture

- `cases/`: canonical theme Markdown, playable JSON and serial authoring sources.
- `src/folk_parser/`: metadata parsing, reference and reachability checks, deterministic offline compilation.
- `src/case_engine/`: shared evidence gates, inference checks and save normalization.
- `src/forum_system/`: the existing playable UI and in-game assets.
- Root `assets/`: repository presentation only; screenshots are captured from the game.

Run `python3 -m src.folk_parser build` after editing content. Planned themes are indexed but never silently registered as playable cases. See the [case catalog](docs/case_list.md) and [installation guide](docs/install_guide.md).

### Scope and provenance

The existing narrative is preserved during this repository migration. Browser saves retain their keys, but moving between file paths, hosts, ports or browsers may require export/import. The game does not use characters, dialogue, plot or artwork from *頭七* and is not affiliated with its creators.

Folklore and mechanisms are fictional writing prompts, not ethnographic or medical claims. The folder name `exclusive-folk-cases` does not imply exclusive rights. A blanket open-source license has **not** yet been chosen; review [NOTICE](NOTICE.md) before redistribution or commercial use.
