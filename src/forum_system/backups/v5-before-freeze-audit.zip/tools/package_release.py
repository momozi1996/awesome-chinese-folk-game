"""Reproducible source + offline demo archive in the unified repository layout."""
from pathlib import Path
import hashlib
import posixpath
import re
import sys
import zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.folk_parser.library import compile_library

def main():
    compile_library()
    out=ROOT/'releases/awesome-chinese-folk-game-v5.0.zip'
    out.parent.mkdir(exist_ok=True)
    exclude={'releases','backups','research','node_modules','.git','__pycache__','.venv'}
    prefix='awesome-chinese-folk-game/'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            rel=p.relative_to(ROOT)
            if not p.is_file() or any(x in exclude for x in rel.parts): continue
            if any(x.startswith('.') and x!='.gitignore' for x in rel.parts): continue
            if 'tests' in rel.parts and any(x.startswith('screenshots') for x in rel.parts): continue
            if p.name.endswith(('.pyc','.blend1','-fixture.json','.log','-results.json')): continue
            info=zipfile.ZipInfo(prefix+rel.as_posix(),date_time=(2026,9,18,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(0o100755 if p.suffix=='.command' else 0o100644)<<16
            z.writestr(info,p.read_bytes())
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        files=set(z.namelist());htmlbase=prefix+'src/forum_system/'
        html=z.read(htmlbase+'index.html').decode()
        for src in re.findall(r'(?:src|href)="([^"]+)"',html):
            if not src.startswith('#'): assert posixpath.normpath(htmlbase+src) in files,src
        assert htmlbase+'soundscape.js' in files and htmlbase+'immersion.css' in files
        assert len([x for x in files if '/assets/textures/' in x and x.endswith('.webp')])==2
        assert len([x for x in files if '/assets/scenes/' in x and x.endswith('.jpg')])==12
        assert len([x for x in files if '/cases/classic-folk-cases/' in x and x.endswith('.md')])==28
        assert len([x for x in files if '/cases/exclusive-folk-cases/' in x and x.endswith('.md')])==30
        assert not any('/research/' in x or '/backups/' in x or '-fixture.json' in x for x in files)
    sha=hashlib.sha256(out.read_bytes()).hexdigest()
    out.with_suffix('.zip.sha256').write_text(sha+'  '+out.name+'\n')
    print(f'{out}\n{out.stat().st_size/1024/1024:.2f} MiB / {len(files)} files / SHA256 {sha}')
if __name__=='__main__': main()
