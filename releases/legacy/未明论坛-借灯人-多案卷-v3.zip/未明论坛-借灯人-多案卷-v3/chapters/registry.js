"use strict";
window.CASES = {
  lantern: Object.assign(window.GAME, {
    id: "lantern",
    no: "001",
    title: "借灯人",
    theme: "河灯 · 旧闻 · 被漏记的人",
    place: "南湾",
    summary: "放下去六盏，飘回来七盏。有人在一张被裁掉的报纸里，等了六年。",
    art: "assets/town-night.jpg",
    length: "20–35 分钟",
    legacy: true,
  }),
};
// Narrative content stays separate from the engine. Values here are authored fiction, not folklore claims.
window.addForumCase = function (c) {
  c.version = 1;
  c.clues = Object.fromEntries(
    c.clues.map((x, i) => [x.id, { ...x, n: String(i + 1).padStart(2, "0") }]),
  );
  c.posts = c.posts.map((p, i) => ({
    category: ["正在发生", "民俗旧闻", "地方志", "地方志", "闲谈", "正在发生"][
      i
    ],
    label: ["求助", "考据", "旧闻", "记录", "怪谈", "续帖"][i],
    avatar: p.author[0],
    time:
      i === 5
        ? "刚刚更新"
        : `当夜 ${["21:06", "20:40", "19:18", "18:32", "17:09"][i]}`,
    views: 317 - i * 29,
    replies: p.comments.length,
    featured: i === 0,
    excerpt: p.body[0].replace(/<[^>]*>/g, ""),
    ...p,
  }));
  c.endings = c.endings.map((e, i) => ({
    ...e,
    code: `ENDING ${String(i + 1).padStart(2, "0")} / ${e.name}`,
  }));
  window.CASES[c.id] = c;
};
