"""Pack the offline game without research, old archives, dependencies or test saves."""
from pathlib import Path
import zipfile, hashlib, re
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'releases'/'未明旧案柜-V4-寄名簿.zip'
out.parent.mkdir(exist_ok=True)
exclude={'releases','backups','research','node_modules','.git','__pycache__'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(ROOT.rglob('*')):
  rel=p.relative_to(ROOT)
  if not p.is_file() or any(x in exclude or x.startswith('.') for x in rel.parts): continue
  if any(x in ('screenshots','screenshots-v4') for x in rel.parts):continue
  if p.name.endswith(('.pyc','.blend1','-fixture.json')):continue
  if p.suffix=='.log' and p.name not in ('validation-v4-final.log','validation-v4-edge.log','validation-v4-content.log'):continue
  z.write(p,Path('wanxiang-forum')/rel)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 files=set(z.namelist())
 html=z.read('wanxiang-forum/index.html').decode()
 for src in re.findall(r'(?:src|href)="([^"]+)"',html):
  if not src.startswith('#'): assert 'wanxiang-forum/'+src in files, src
 assert len([x for x in files if '/assets/scenes/' in x and x.endswith('.jpg')])==12
 assert not any('/releases/' in x or '/research/' in x or '-fixture.json' in x for x in files)
sha=hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix('.zip.sha256').write_text(sha+'  '+out.name+'\n')
print(out)
print(f'{out.stat().st_size/1024/1024:.2f} MiB / {len(files)} files / SHA256 {sha}')
