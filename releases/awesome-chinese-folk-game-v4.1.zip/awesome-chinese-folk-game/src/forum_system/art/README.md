# 原创现场资产 / V4

`source/build_scenes.py` 是全部十二幅三维现场的确定性源代码。没有外部模型、贴图库或参考游戏素材；不使用 AI 生图 API。渲染器为本机 Blender / Cycles，1536×960。

```sh
blender -b --python art/source/build_scenes.py
# 单独重建某一处
blender -b --python art/source/build_scenes.py -- mirror
```

输出：`../assets/scenes/*.jpg`。`source/latest-set.blend` 保存最后渲染的场景，其他场景可由脚本重建。灯台、旧镜、寄存衣物、井沿、邮袋柜和宗堂空椅分别对应实地取证，不作为宣传页背景。画面内无必须辨认的文字，所有关键信息均提供可访问的文字转录与热点按钮。

旧版 SVG 与首案夜景仍保留，不覆盖备份。音效默认关闭；证据不依赖音频。
